#ifndef _TRACE_H
#define _TRACE_H

#include <sys/types.h>

void setup_trace();
void trace_loop();
void agent_loop(pid_t pid);

#endif
