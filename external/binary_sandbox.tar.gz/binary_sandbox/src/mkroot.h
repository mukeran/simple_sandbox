#ifndef _MKROOT_H
#define _MKROOT_H

void copy_dependencies(const char *root, const char *path_bin);
int mkroot(const char *root);

#endif